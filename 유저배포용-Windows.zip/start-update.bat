@echo off
chcp 65001 >nul
title Minecraft 서버 업데이터
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0updater.ps1"
echo.
pause
