﻿<#
  Minecraft One-Click Updater
  -------------------------------------------------------------
  manifest.json 을 읽어서 서버 패치를 자동 적용합니다.
   - download : 파일 다운로드 / 덮어쓰기 (해시가 같으면 건너뜀)
   - delete   : 특정 파일 삭제
   - patch    : options.txt 같은 설정 파일에서 '특정 줄만' 수정
  이 파일은 유저가 직접 열 필요 없습니다. start-update.bat 을 실행하면 됩니다.
#>

$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Info($msg)  { Write-Host "  $msg" }
function Write-OK($msg)    { Write-Host "  [OK] $msg"   -ForegroundColor Green }
function Write-Skip($msg)  { Write-Host "  [--] $msg"   -ForegroundColor DarkGray }
function Write-Del($msg)   { Write-Host "  [삭제] $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "  [실패] $msg" -ForegroundColor Red }

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "        Minecraft 서버 자동 업데이터" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

# ---------- 1. 설정 읽기 ----------
$configPath = Join-Path $scriptDir 'config.json'
if (-not (Test-Path $configPath)) { Write-Err "config.json 이 없습니다."; Read-Host "엔터를 누르면 종료"; exit 1 }
$config = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$manifestUrl = $config.manifestUrl

# ---------- 2. 마인크래프트 폴더 찾기 ----------
if ($config.minecraftDir -and $config.minecraftDir.Trim() -ne '') {
    $mcDir = [Environment]::ExpandEnvironmentVariables($config.minecraftDir)
} else {
    $mcDir = Join-Path $env:APPDATA '.minecraft'
}
if (-not (Test-Path $mcDir)) {
    Write-Err ".minecraft 폴더를 찾을 수 없습니다: $mcDir"
    Write-Info "→ 서버가 처음이라면: 마인크래프트와 모드로더(Forge/Fabric 등)를 먼저 설치하고,"
    Write-Info "  그 로더로 게임을 '한 번' 실행한 뒤 이 프로그램을 다시 실행하세요."
    Write-Info "→ 프리즘런처 등 다른 런처를 쓴다면: config.json 의 minecraftDir 에 게임 폴더 경로를 적어주세요."
    Read-Host "엔터를 누르면 종료"; exit 1
}
Write-Info "대상 폴더 : $mcDir"

# ---------- 3. manifest 내려받기 ----------
Write-Info "패치 정보 확인 중..."
try {
    $manifest = Invoke-RestMethod -Uri $manifestUrl -UseBasicParsing
} catch {
    Write-Err "패치 정보를 불러오지 못했습니다. 인터넷 연결을 확인하세요."
    Read-Host "엔터를 누르면 종료"; exit 1
}
Write-OK "패치 버전: $($manifest.version)"
Write-Host ""

$downloaded = 0; $skipped = 0; $deleted = 0; $patched = 0; $failed = 0

# ---------- 4. 파일 다운로드 / 삭제 ----------
if ($manifest.files) {
    Write-Host "[모드/파일 적용]" -ForegroundColor Cyan
    foreach ($f in $manifest.files) {
        try {
            if ($f.action -eq 'delete') {
                $target = Join-Path $mcDir ($f.path -replace '/', '\')
                if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force; Write-Del $f.path; $deleted++ }
                continue
            }
            if ($f.action -eq 'download') {
                $dest = Join-Path $mcDir ($f.dest -replace '/', '\')

                # 이미 같은 파일이면 건너뜀 (sha1 비교). force=true 면 무조건 새로 받음
                if ((-not $f.force) -and (Test-Path -LiteralPath $dest) -and $f.sha1) {
                    $localHash = (Get-FileHash -Algorithm SHA1 -LiteralPath $dest).Hash
                    if ($localHash -ieq $f.sha1) { Write-Skip "$($f.dest) (변경 없음)"; $skipped++; continue }
                }

                $destDir = Split-Path -Parent $dest
                if (-not (Test-Path -LiteralPath $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }

                # [ ] 같은 특수문자가 든 경로도 안전하도록, 임시 이름(GUID)으로 받아서 옮김
                $tmp = Join-Path $destDir ("dl_" + [guid]::NewGuid().ToString("N") + ".tmp")
                $safeUrl = [uri]::EscapeUriString($f.url)
                Invoke-WebRequest -Uri $safeUrl -OutFile $tmp -UseBasicParsing

                # 해시 검증 (있을 때만)
                if ($f.sha1) {
                    $dlHash = (Get-FileHash -Algorithm SHA1 -LiteralPath $tmp).Hash
                    if ($dlHash -ine $f.sha1) { Remove-Item -LiteralPath $tmp -Force; throw "해시 불일치" }
                }
                if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force }
                [System.IO.File]::Move($tmp, $dest)
                Write-OK "$($f.dest)"; $downloaded++
            }
        } catch {
            Write-Err "$($f.dest)$($f.path)  ($($_.Exception.Message))"; $failed++
        }
    }
    Write-Host ""
}

# ---------- 5. 옵션 파일에서 '특정 줄만' 수정 ----------
if ($manifest.optionPatches) {
    Write-Host "[설정 값 조정 (다른 설정은 유지)]" -ForegroundColor Cyan
    foreach ($p in $manifest.optionPatches) {
        try {
            $sep  = if ($p.separator) { $p.separator } else { ':' }
            $full = Join-Path $mcDir ($p.file -replace '/', '\')

            $lines = @()
            if (Test-Path $full) { $lines = [System.IO.File]::ReadAllLines($full) }

            $remaining = @{}
            foreach ($prop in $p.set.PSObject.Properties) { $remaining[$prop.Name] = [string]$prop.Value }

            $out = New-Object System.Collections.Generic.List[string]
            foreach ($line in $lines) {
                $idx = $line.IndexOf($sep)
                if ($idx -gt 0) {
                    $key = $line.Substring(0, $idx)
                    if ($remaining.ContainsKey($key)) {
                        $out.Add("$key$sep$($remaining[$key])")
                        $remaining.Remove($key) | Out-Null
                        continue
                    }
                }
                $out.Add($line)
            }
            foreach ($k in $remaining.Keys) { $out.Add("$k$sep$($remaining[$k])") }

            $destDir = Split-Path -Parent $full
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            $enc = New-Object System.Text.UTF8Encoding($false)   # BOM 없이 저장
            [System.IO.File]::WriteAllLines($full, $out, $enc)

            $keys = ($p.set.PSObject.Properties.Name) -join ', '
            Write-OK "$($p.file)  →  $keys"; $patched++
        } catch {
            Write-Err "$($p.file)  ($($_.Exception.Message))"; $failed++
        }
    }
    Write-Host ""
}

# ---------- 5.5 동기화: 목록에 없는 파일 자동 삭제 (안전을 위해 mods 폴더만 허용) ----------
$syncFolders = @()
if ($manifest.syncFolders) {
    $syncFolders = @($manifest.syncFolders | Where-Object { (($_ -replace '\\','/').Trim('/')).ToLower() -eq 'mods' })
}
if ($syncFolders.Count -gt 0) {
    if ($failed -gt 0) {
        Write-Host "  [주의] 다운로드 실패가 있어 폴더 동기화(정리)는 이번에 건너뜁니다." -ForegroundColor Yellow
        Write-Host ""
    } else {
        $wanted = @{}
        foreach ($f in $manifest.files) {
            if ($f.action -eq 'download' -and $f.dest) {
                $wanted[($f.dest -replace '\\','/').TrimStart('/')] = $true
            }
        }
        Write-Host "[폴더 동기화 (목록에 없는 파일 정리)]" -ForegroundColor Cyan
        foreach ($folder in $syncFolders) {
            $folderClean = ($folder -replace '\\','/').Trim('/')
            $base = Join-Path $mcDir ($folderClean -replace '/', '\')
            if (-not (Test-Path -LiteralPath $base)) { continue }
            Get-ChildItem -LiteralPath $base -Recurse -File | ForEach-Object {
                $rel = $_.FullName.Substring($mcDir.Length).TrimStart('\','/') -replace '\\','/'
                if (-not $wanted.ContainsKey($rel)) {
                    try { Remove-Item -LiteralPath $_.FullName -Force; Write-Del "$rel (목록에 없음)"; $deleted++ }
                    catch { Write-Err "$rel  ($($_.Exception.Message))"; $failed++ }
                }
            }
        }
        Write-Host ""
    }
}

# ---------- 6. 요약 ----------
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host " 완료!  받음 $downloaded · 유지 $skipped · 삭제 $deleted · 설정 $patched · 실패 $failed"
if ($failed -gt 0) { Write-Host " 일부 항목이 실패했습니다. 위 빨간 줄을 확인하세요." -ForegroundColor Red }
else { Write-Host " 모든 패치가 정상 적용되었습니다. 게임을 실행하세요." -ForegroundColor Green }
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""
