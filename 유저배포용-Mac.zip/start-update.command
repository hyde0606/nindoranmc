#!/bin/bash
# 맥에서 이 파일을 더블클릭하면 업데이터가 실행됩니다.
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo ""
  echo "  python3 가 설치되어 있지 않습니다."
  echo "  안내창이 뜨면 '설치'를 눌러 명령어 도구(Command Line Tools)를 설치한 뒤 다시 실행하세요."
  echo ""
  xcode-select --install 2>/dev/null
  read -n 1 -s -r -p "아무 키나 누르면 닫힙니다..."
  exit 1
fi

python3 updater.py
echo ""
read -n 1 -s -r -p "종료하려면 아무 키나 누르세요..."
