#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Minecraft One-Click Updater (Mac / Linux 용)
------------------------------------------------------------
Windows 버전(updater.ps1)과 완전히 동일한 manifest.json / config.json 을 사용합니다.
  - download : 파일 다운로드 / 덮어쓰기 (해시 같으면 건너뜀)
  - delete   : 특정 파일 삭제
  - patch    : options.txt 등에서 '특정 줄만' 수정 (나머지 설정 유지)
유저는 이 파일을 직접 열 필요 없습니다. start-update.command(맥) 를 실행하세요.
추가 설치 없이 python3 만 있으면 됩니다.
"""

import os
import sys
import json
import shutil
import hashlib
import platform
import urllib.request
import urllib.error
from urllib.parse import quote, urlsplit, urlunsplit

# ---------- 콘솔 색상 ----------
def _supports_color():
    return sys.stdout.isatty()
C = _supports_color()
GRN = "\033[32m" if C else ""
YEL = "\033[33m" if C else ""
RED = "\033[31m" if C else ""
GRY = "\033[90m" if C else ""
CYN = "\033[36m" if C else ""
RST = "\033[0m" if C else ""

def info(m): print(f"  {m}")
def ok(m):   print(f"  {GRN}[OK] {m}{RST}")
def skip(m): print(f"  {GRY}[--] {m}{RST}")
def dele(m): print(f"  {YEL}[삭제] {m}{RST}")
def err(m):  print(f"  {RED}[실패] {m}{RST}")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def die(msg):
    err(msg)
    sys.exit(1)

# ---------- 마인크래프트 폴더 찾기 ----------
def resolve_mc_dir(cfg):
    md = (cfg.get("minecraftDir") or "").strip()
    if md:
        return os.path.expanduser(os.path.expandvars(md))
    system = platform.system()
    if system == "Darwin":                       # macOS
        return os.path.expanduser("~/Library/Application Support/minecraft")
    elif system == "Windows":
        return os.path.join(os.environ.get("APPDATA", ""), ".minecraft")
    else:                                        # Linux 등
        return os.path.expanduser("~/.minecraft")

# ---------- 경로 변환 (manifest 는 항상 / 사용) ----------
def local_path(mc_dir, rel):
    rel = rel.replace("\\", "/").lstrip("/")
    return os.path.join(mc_dir, *rel.split("/"))

# ---------- SHA1 ----------
def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

# ---------- 다운로드 ----------
def safe_url(url):
    # 주소에 한글 등 비ASCII 문자가 있어도 정상 처리 (이미 %.. 로 인코딩된 부분은 그대로 둠)
    p = urlsplit(url)
    path = quote(p.path, safe="/%-._~!$&'()*+,;=:@")
    query = quote(p.query, safe="/%-._~!$&'()*+,;=:@?")
    return urlunsplit((p.scheme, p.netloc, path, query, p.fragment))

def http_get(url, timeout=60):
    req = urllib.request.Request(safe_url(url), headers={"User-Agent": "mc-updater"})
    return urllib.request.urlopen(req, timeout=timeout)

def download(url, dest, sha1, force=False):
    # force=True 면 해시가 있어도 무조건 새로 받아 덮어씀
    if (not force) and os.path.exists(dest) and sha1:
        if sha1_of(dest).lower() == sha1.lower():
            return "skip"
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    tmp = dest + ".downloading"
    with http_get(url) as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f)
    if sha1 and sha1_of(tmp).lower() != sha1.lower():
        os.remove(tmp)
        raise ValueError("해시 불일치")
    os.replace(tmp, dest)
    return "download"

# ---------- 옵션 파일 특정 줄만 수정 ----------
def patch_options(full, sep, sets):
    lines = []
    if os.path.exists(full):
        with open(full, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    remaining = dict(sets)
    out = []
    for line in lines:
        idx = line.find(sep)
        if idx > 0:
            key = line[:idx]
            if key in remaining:
                out.append(f"{key}{sep}{remaining[key]}")
                del remaining[key]
                continue
        out.append(line)
    for k, v in remaining.items():
        out.append(f"{k}{sep}{v}")
    os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
    with open(full, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + ("\n" if out else ""))

# ---------- 메인 ----------
def main():
    print()
    print(f"{CYN}=================================================={RST}")
    print(f"{CYN}        Minecraft 서버 자동 업데이터{RST}")
    print(f"{CYN}=================================================={RST}")
    print()

    cfg_path = os.path.join(SCRIPT_DIR, "config.json")
    if not os.path.exists(cfg_path):
        die("config.json 이 없습니다.")
    with open(cfg_path, "r", encoding="utf-8-sig") as f:
        cfg = json.load(f)

    manifest_url = cfg.get("manifestUrl", "")
    mc_dir = resolve_mc_dir(cfg)
    if not os.path.isdir(mc_dir):
        die(f".minecraft 폴더를 찾을 수 없습니다: {mc_dir}\n"
            "   → 서버가 처음이라면: 마인크래프트와 모드로더(Forge/Fabric 등)를 먼저 설치하고,\n"
            "     그 로더로 게임을 '한 번' 실행한 뒤 이 프로그램을 다시 실행하세요.\n"
            "   → 프리즘런처 등 다른 런처를 쓴다면: config.json 의 minecraftDir 에 게임 폴더 경로를 적어주세요.")
    info(f"대상 폴더 : {mc_dir}")

    info("패치 정보 확인 중...")
    try:
        with http_get(manifest_url, timeout=30) as r:
            manifest = json.loads(r.read().decode("utf-8-sig"))
    except urllib.error.URLError as e:
        die(f"패치 정보를 불러오지 못했습니다. 인터넷 연결을 확인하세요. ({e})")
    ok(f"패치 버전: {manifest.get('version', '?')}")
    print()

    dl = sk = de = pa = fa = 0

    files = manifest.get("files") or []
    if files:
        print(f"{CYN}[모드/파일 적용]{RST}")
        for f in files:
            action = f.get("action")
            try:
                if action == "delete":
                    target = local_path(mc_dir, f["path"])
                    if os.path.exists(target):
                        os.remove(target); dele(f["path"]); de += 1
                elif action == "download":
                    dest = local_path(mc_dir, f["dest"])
                    res = download(f["url"], dest, f.get("sha1"), f.get("force", False))
                    if res == "skip":
                        skip(f"{f['dest']} (변경 없음)"); sk += 1
                    else:
                        ok(f["dest"]); dl += 1
            except Exception as e:
                err(f"{f.get('dest') or f.get('path')}  ({e})"); fa += 1
        print()

    patches = manifest.get("optionPatches") or []
    if patches:
        print(f"{CYN}[설정 값 조정 (다른 설정은 유지)]{RST}")
        for p in patches:
            try:
                sep = p.get("separator") or ":"
                full = local_path(mc_dir, p["file"])
                patch_options(full, sep, p.get("set") or {})
                keys = ", ".join((p.get("set") or {}).keys())
                ok(f"{p['file']}  →  {keys}"); pa += 1
            except Exception as e:
                err(f"{p.get('file')}  ({e})"); fa += 1
        print()

    # ---- 동기화: 목록에 없는 파일 자동 삭제 (안전을 위해 mods 폴더만 허용) ----
    sync_folders = [s for s in (manifest.get("syncFolders") or [])
                    if str(s).replace("\\", "/").strip("/").lower() == "mods"]
    if sync_folders and fa > 0:
        print(f"{YEL}  [주의] 다운로드 실패가 있어 폴더 동기화(정리)는 이번에 건너뜁니다.{RST}\n")
    elif sync_folders:
        wanted = set()
        for f in files:
            if f.get("action") == "download" and f.get("dest"):
                wanted.add(f["dest"].replace("\\", "/").lstrip("/"))
        print(f"{CYN}[폴더 동기화 (목록에 없는 파일 정리)]{RST}")
        for folder in sync_folders:
            folder_clean = folder.replace("\\", "/").strip("/")
            base = local_path(mc_dir, folder_clean)
            if not os.path.isdir(base):
                continue
            for root, _, names in os.walk(base):
                for name in names:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, mc_dir).replace("\\", "/")
                    if rel not in wanted:
                        try:
                            os.remove(full); dele(f"{rel} (목록에 없음)"); de += 1
                        except Exception as e:
                            err(f"{rel}  ({e})"); fa += 1
        print()

    print(f"{CYN}=================================================={RST}")
    print(f" 완료!  받음 {dl} · 유지 {sk} · 삭제 {de} · 설정 {pa} · 실패 {fa}")
    if fa > 0:
        print(f"{RED} 일부 항목이 실패했습니다. 위 빨간 줄을 확인하세요.{RST}")
    else:
        print(f"{GRN} 모든 패치가 정상 적용되었습니다. 게임을 실행하세요.{RST}")
    print(f"{CYN}=================================================={RST}")
    print()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
